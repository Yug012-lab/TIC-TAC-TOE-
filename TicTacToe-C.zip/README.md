# Tic Tac Toe in C

🎮 A simple 2-player Tic Tac Toe game made using C language. This project runs in the terminal and helps beginners understand arrays, conditionals, and functions.

## 📦 Features
- 2-player support
- Console-based UI
- Input validation
- Win and draw detection

## 🛠 Compile and Run

```bash
gcc main.c -o tictactoe
./tictactoe
```

## 📚 Topics Covered
- 2D arrays
- Functions
- Conditionals
- Loops
